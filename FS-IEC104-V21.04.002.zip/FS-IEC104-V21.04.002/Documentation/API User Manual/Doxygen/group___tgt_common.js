var group___tgt_common =
[
    [ "sSETTimeStamp", "structs_s_e_t_time_stamp.html", [
      [ "i8DSTTime", "structs_s_e_t_time_stamp_a80009bea0600b0aa232f6a6a82d353d4.html#a80009bea0600b0aa232f6a6a82d353d4", null ],
      [ "u16MicroSeconds", "structs_s_e_t_time_stamp_abbb3c3230d42995580d7ae05810c0b58.html#abbb3c3230d42995580d7ae05810c0b58", null ],
      [ "u16MilliSeconds", "structs_s_e_t_time_stamp_a1ab6a41864154593e488320ec6ed1bd8.html#a1ab6a41864154593e488320ec6ed1bd8", null ],
      [ "u16Year", "structs_s_e_t_time_stamp_a7a8245510b2f221fe340d5bcc499a3d4.html#a7a8245510b2f221fe340d5bcc499a3d4", null ],
      [ "u8Day", "structs_s_e_t_time_stamp_a02cb7bb2df80eba91cb0c3c71eea6367.html#a02cb7bb2df80eba91cb0c3c71eea6367", null ],
      [ "u8DayoftheWeek", "structs_s_e_t_time_stamp_ac13624dfbfa50ef69b8410a3159e90a8.html#ac13624dfbfa50ef69b8410a3159e90a8", null ],
      [ "u8Hour", "structs_s_e_t_time_stamp_a2f6fc3efbe1a069b77357d66bbf9c159.html#a2f6fc3efbe1a069b77357d66bbf9c159", null ],
      [ "u8Minute", "structs_s_e_t_time_stamp_a93719e22490a6bfd2b9974e9fd461be3.html#a93719e22490a6bfd2b9974e9fd461be3", null ],
      [ "u8Month", "structs_s_e_t_time_stamp_a9105dbd153f2439928cdcded08099b92.html#a9105dbd153f2439928cdcded08099b92", null ],
      [ "u8Seconds", "structs_s_e_t_time_stamp_a7277f533aee4cef495ee928bb0bd1a86.html#a7277f533aee4cef495ee928bb0bd1a86", null ]
    ] ],
    [ "eApplicationFlag", "group___tgt_common_ga3d42d9403435f3ecd781fd6604e9b0f9.html#ga3d42d9403435f3ecd781fd6604e9b0f9", [
      [ "APP_SERVER", "group___tgt_common_ga3d42d9403435f3ecd781fd6604e9b0f9.html#gga3d42d9403435f3ecd781fd6604e9b0f9acebb8f40c4b86c73999a94e27e638044", null ],
      [ "APP_CLIENT", "group___tgt_common_ga3d42d9403435f3ecd781fd6604e9b0f9.html#gga3d42d9403435f3ecd781fd6604e9b0f9ae77dbbf610916cb6783ff29cfd39502a", null ],
      [ "APP_SERVERCLIENT", "group___tgt_common_ga3d42d9403435f3ecd781fd6604e9b0f9.html#gga3d42d9403435f3ecd781fd6604e9b0f9a02a66a5ff530aff80881dcd78af24fc7", null ]
    ] ],
    [ "eDataTypes", "group___tgt_common_ga46a1c66e981a079fa9e5d6eb02fdea86.html#ga46a1c66e981a079fa9e5d6eb02fdea86", [
      [ "UNSUPPORTED_DATA", "group___tgt_common_ga46a1c66e981a079fa9e5d6eb02fdea86.html#gga46a1c66e981a079fa9e5d6eb02fdea86a0bbdcd47f5f3221e8c34be3157a10eb2", null ],
      [ "SINGLE_POINT_DATA", "group___tgt_common_ga46a1c66e981a079fa9e5d6eb02fdea86.html#gga46a1c66e981a079fa9e5d6eb02fdea86a5072f14a923c326fe20dc62d4056a1d6", null ],
      [ "DOUBLE_POINT_DATA", "group___tgt_common_ga46a1c66e981a079fa9e5d6eb02fdea86.html#gga46a1c66e981a079fa9e5d6eb02fdea86a2c61d4d79f78fdddd924c21fb7776b46", null ],
      [ "UNSIGNED_BYTE_DATA", "group___tgt_common_ga46a1c66e981a079fa9e5d6eb02fdea86.html#gga46a1c66e981a079fa9e5d6eb02fdea86a160b7c18d824b50b7cdbd1431fffc87d", null ],
      [ "SIGNED_BYTE_DATA", "group___tgt_common_ga46a1c66e981a079fa9e5d6eb02fdea86.html#gga46a1c66e981a079fa9e5d6eb02fdea86aebc2bb0307b3aa2ea14cd88e26c9bc68", null ],
      [ "UNSIGNED_WORD_DATA", "group___tgt_common_ga46a1c66e981a079fa9e5d6eb02fdea86.html#gga46a1c66e981a079fa9e5d6eb02fdea86a26a301098a0571f03a6999cf4164b688", null ],
      [ "SIGNED_WORD_DATA", "group___tgt_common_ga46a1c66e981a079fa9e5d6eb02fdea86.html#gga46a1c66e981a079fa9e5d6eb02fdea86ab605c8569299b2cfddfb78a42a6bd8bd", null ],
      [ "UNSIGNED_DWORD_DATA", "group___tgt_common_ga46a1c66e981a079fa9e5d6eb02fdea86.html#gga46a1c66e981a079fa9e5d6eb02fdea86a5f73418fc69990e0aef5d482246d7264", null ],
      [ "SIGNED_DWORD_DATA", "group___tgt_common_ga46a1c66e981a079fa9e5d6eb02fdea86.html#gga46a1c66e981a079fa9e5d6eb02fdea86a58a292c7a0ebb2929cf821e4d3694ac9", null ],
      [ "UNSIGNED_LWORD_DATA", "group___tgt_common_ga46a1c66e981a079fa9e5d6eb02fdea86.html#gga46a1c66e981a079fa9e5d6eb02fdea86a6b72ad173f471bb0a31aa8dae8a79430", null ],
      [ "SIGNED_LWORD_DATA", "group___tgt_common_ga46a1c66e981a079fa9e5d6eb02fdea86.html#gga46a1c66e981a079fa9e5d6eb02fdea86a8c2e154535ed9e133871bb3f497d9e64", null ],
      [ "UNSIGNED_LLWORD_DATA", "group___tgt_common_ga46a1c66e981a079fa9e5d6eb02fdea86.html#gga46a1c66e981a079fa9e5d6eb02fdea86a017a3ac6d8bad7517b3d4b931321531f", null ],
      [ "SIGNED_LLWORD_DATA", "group___tgt_common_ga46a1c66e981a079fa9e5d6eb02fdea86.html#gga46a1c66e981a079fa9e5d6eb02fdea86ac54470e679734db497503184a1a1edd8", null ],
      [ "FLOAT32_DATA", "group___tgt_common_ga46a1c66e981a079fa9e5d6eb02fdea86.html#gga46a1c66e981a079fa9e5d6eb02fdea86a3a113dddebed669042cc348d1e4025d2", null ],
      [ "FLOAT64_DATA", "group___tgt_common_ga46a1c66e981a079fa9e5d6eb02fdea86.html#gga46a1c66e981a079fa9e5d6eb02fdea86ad3f37f379e812d50d7120e5cade67141", null ],
      [ "FLOAT128_DATA", "group___tgt_common_ga46a1c66e981a079fa9e5d6eb02fdea86.html#gga46a1c66e981a079fa9e5d6eb02fdea86ada3cda73914ca10da9102a26d7884c3d", null ],
      [ "VISIBLE_STRING_DATA", "group___tgt_common_ga46a1c66e981a079fa9e5d6eb02fdea86.html#gga46a1c66e981a079fa9e5d6eb02fdea86a65d1a0bf3f9227334f982519637f895d", null ]
    ] ],
    [ "eDebugOptionsFlag", "group___tgt_common_ga83267e88a2a1f8e70498db7d701715bb.html#ga83267e88a2a1f8e70498db7d701715bb", [
      [ "DEBUG_OPTION_NONE", "group___tgt_common_ga83267e88a2a1f8e70498db7d701715bb.html#gga83267e88a2a1f8e70498db7d701715bbaee4b7ef22301bfe358610b6187a325f1", null ],
      [ "DEBUG_OPTION_ERROR", "group___tgt_common_ga83267e88a2a1f8e70498db7d701715bb.html#gga83267e88a2a1f8e70498db7d701715bba9072fa6e75fbfe9f71b94c52f5849e1e", null ],
      [ "DEBUG_OPTION_WARNING", "group___tgt_common_ga83267e88a2a1f8e70498db7d701715bb.html#gga83267e88a2a1f8e70498db7d701715bba829d6e139935d35e32ceec2f641c7bbb", null ],
      [ "DEBUG_OPTION_RX", "group___tgt_common_ga83267e88a2a1f8e70498db7d701715bb.html#gga83267e88a2a1f8e70498db7d701715bba3755f66e8db9025903ab0e65237e1f3f", null ],
      [ "DEBUG_OPTION_TX", "group___tgt_common_ga83267e88a2a1f8e70498db7d701715bb.html#gga83267e88a2a1f8e70498db7d701715bba758b568d1f9e525dffae4792f922cfc6", null ]
    ] ]
];