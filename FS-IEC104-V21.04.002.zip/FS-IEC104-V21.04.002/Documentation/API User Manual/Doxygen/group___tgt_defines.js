var group___tgt_defines =
[
    [ "FALSE", "group___tgt_defines_gaa93f0eb578d23995850d61f7d61c55c1.html#gaa93f0eb578d23995850d61f7d61c55c1", null ],
    [ "MAX_ERROR_MESSAGE", "group___tgt_defines_gaaf754d4c3b13102a9a560bf76516f3fe.html#gaaf754d4c3b13102a9a560bf76516f3fe", null ],
    [ "MAX_IPV4_ADDRSIZE", "group___tgt_defines_ga0e9fc089a661f53fcd68d5205c4107c6.html#ga0e9fc089a661f53fcd68d5205c4107c6", null ],
    [ "MAX_IPV6_ADDRSIZE", "group___tgt_defines_ga02c5a04b814f6d6e38d0129e6a9f521c.html#ga02c5a04b814f6d6e38d0129e6a9f521c", null ],
    [ "MAX_LICENSE_PATH", "group___tgt_defines_ga72791169fd2e668beffb865326b79bc3.html#ga72791169fd2e668beffb865326b79bc3", null ],
    [ "MAX_WARNING_MESSAGE", "group___tgt_defines_gad912a8f2bbf326bd1ce827a86663e168.html#gad912a8f2bbf326bd1ce827a86663e168", null ],
    [ "TRUE", "group___tgt_defines_gaa8cecfc5c5c054d2875c03e77b7be15d.html#gaa8cecfc5c5c054d2875c03e77b7be15d", null ],
    [ "UNUSED", "group___tgt_defines_gaea1d71af1a30c261dbd16745c82e94ba.html#gaea1d71af1a30c261dbd16745c82e94ba", null ],
    [ "ZERO", "group___tgt_defines_gac328e551bde3d39b6d7b8cc9e048d941.html#gac328e551bde3d39b6d7b8cc9e048d941", null ]
];