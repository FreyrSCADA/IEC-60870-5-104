var modules =
[
    [ "IEC60870-5-104 API", "group___i_e_c104_a_p_i.html", "group___i_e_c104_a_p_i" ],
    [ "Call-back IEC60870-5-104 API Call-back functions", "group___i_e_c104.html", "group___i_e_c104" ],
    [ "Target Common Definitions", "group___tgt_common.html", "group___tgt_common" ],
    [ "Target Definitions", "group___tgt_defines.html", "group___tgt_defines" ],
    [ "Error Codes", "group___error_codes.html", "group___error_codes" ],
    [ "Error Values", "group___error_values.html", "group___error_values" ],
    [ "Target Includes", "group___tgt_includes.html", null ]
];