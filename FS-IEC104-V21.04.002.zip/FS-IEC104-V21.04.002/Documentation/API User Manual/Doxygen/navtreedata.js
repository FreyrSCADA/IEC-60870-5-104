/*
@ @licstart  The following is the entire license notice for the
JavaScript code in this file.

Copyright (C) 1997-2017 by Dimitri van Heesch

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 GNU General Public License for more details.

You should have received a copy of the GNU General Public License along
with this program; if not, write to the Free Software Foundation, Inc.,
51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.

@licend  The above is the entire license notice
for the JavaScript code in this file
*/
var NAVTREE =
[
  [ "IEC 60870-5-104  Library", "index.html", [
    [ "API Manual", "index.html#APIMan", null ],
    [ "References", "index.html#References", null ],
    [ "Introduction", "intro.html", null ],
    [ "API Overview", "_overview.html", null ],
    [ "IEC60870-5-104 Server", "_server.html", null ],
    [ "IEC60870-5-104 Client", "_client.html", null ],
    [ "List of Abbreviations", "_abbreviations.html", null ],
    [ "Document Reference", "_reference.html", null ],
    [ "Modules", "modules.html", "modules" ],
    [ "Data Structures", "annotated.html", [
      [ "Data Structures", "annotated.html", "annotated_dup" ],
      [ "Data Structure Index", "classes.html", null ],
      [ "Data Fields", "functions.html", [
        [ "All", "functions.html", "functions_dup" ],
        [ "Functions", "functions_func.html", null ],
        [ "Variables", "functions_vars.html", "functions_vars" ],
        [ "Enumerations", "functions_enum.html", null ]
      ] ]
    ] ],
    [ "Files", "files.html", [
      [ "File List", "files.html", "files_dup" ],
      [ "Globals", "globals.html", [
        [ "All", "globals.html", "globals_dup" ],
        [ "Functions", "globals_func.html", null ],
        [ "Typedefs", "globals_type.html", null ],
        [ "Enumerations", "globals_enum.html", null ],
        [ "Enumerator", "globals_eval.html", "globals_eval" ],
        [ "Macros", "globals_defs.html", null ]
      ] ]
    ] ],
    [ "Examples", "examples.html", "examples" ]
  ] ]
];

var NAVTREEINDEX =
[
"_abbreviations.html",
"classiec104_a18ac24b30a5cf989b7fd4b9ad9efa59b.html#a18ac24b30a5cf989b7fd4b9ad9efa59ba6725773b3371787d2445c3dfad2d68fb",
"classiec104_a228d84104c7b2546051ddd4b70be7e68.html#a228d84104c7b2546051ddd4b70be7e68a61cc8edc276907d508d58445d4bc7278",
"classiec104_a31a560146a597889f6ca5ad75a38a923.html#a31a560146a597889f6ca5ad75a38a923a92ccb9ae6c8da93d9f13ec036ef598aa",
"classiec104_a4fa6bb3947ef41c5d78aec2beb7c5034.html#a4fa6bb3947ef41c5d78aec2beb7c5034abdae12b6743317ed9180c907e8768062",
"classiec104_a98f62c57ed523529b59eaed90540d23d.html#a98f62c57ed523529b59eaed90540d23d",
"group___error_codes_ga228d84104c7b2546051ddd4b70be7e68.html#gga228d84104c7b2546051ddd4b70be7e68a1fec51db982a21b570507752b024aa8d",
"group___i_e_c104_a_p_i_ga4b335faf227e3265b66b0ab0329157e9.html#ga4b335faf227e3265b66b0ab0329157e9",
"iec104types_8h_a31a560146a597889f6ca5ad75a38a923.html#a31a560146a597889f6ca5ad75a38a923a9c922c72676cab2b540d081a8bb3788a",
"structiec104_1_1s_client_connection_parameters_af633601c92b41a263568ac59fdbf4a09.html#af633601c92b41a263568ac59fdbf4a09",
"structs_i_e_c104_debug_parameters_aea82b8e3059cf0b9dfb7f6feb4324cc7.html#aea82b8e3059cf0b9dfb7f6feb4324cc7"
];

var SYNCONMSG = 'click to disable panel synchronisation';
var SYNCOFFMSG = 'click to enable panel synchronisation';