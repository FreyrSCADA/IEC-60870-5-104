var structiec104_1_1s_client_settings =
[
    [ "bAutoGenIEC104DataObjects", "structiec104_1_1s_client_settings_aaaf3d38f5c1ad313090b7a361cac163c.html#aaaf3d38f5c1ad313090b7a361cac163c", null ],
    [ "bClientAcceptTCPconnection", "structiec104_1_1s_client_settings_a297c69f9a6559a748c5b769b1be6f675.html#a297c69f9a6559a748c5b769b1be6f675", null ],
    [ "benabaleUTCtime", "structiec104_1_1s_client_settings_a01698d8a036e93f1900c9d571734e6f2.html#a01698d8a036e93f1900c9d571734e6f2", null ],
    [ "psClientConParameters", "structiec104_1_1s_client_settings_ad9118223e5a0d183ed94fe57aef7534a.html#ad9118223e5a0d183ed94fe57aef7534a", null ],
    [ "sDebug", "structiec104_1_1s_client_settings_ad0dbabf645d059cc583088a6c28b4df3.html#ad0dbabf645d059cc583088a6c28b4df3", null ],
    [ "u16TotalNumberofConnection", "structiec104_1_1s_client_settings_a7884e17fb25d75dbda2db8111c4d9a5d.html#a7884e17fb25d75dbda2db8111c4d9a5d", null ]
];