var structiec104_1_1s_i_e_c104_data_attribute_data =
[
    [ "bTimeInvalid", "structiec104_1_1s_i_e_c104_data_attribute_data_af13ed543cf295965f908c0069e902c32.html#af13ed543cf295965f908c0069e902c32", null ],
    [ "eDataSize", "structiec104_1_1s_i_e_c104_data_attribute_data_a848c30aed373d023fd4ba4dbf4f4e5d6.html#a848c30aed373d023fd4ba4dbf4f4e5d6", null ],
    [ "eDataType", "structiec104_1_1s_i_e_c104_data_attribute_data_a1baa170ae2305e8c74feda69a6142614.html#a1baa170ae2305e8c74feda69a6142614", null ],
    [ "eTimeQuality", "structiec104_1_1s_i_e_c104_data_attribute_data_a36f9f25068abe0683b0bb3c408fba6d0.html#a36f9f25068abe0683b0bb3c408fba6d0", null ],
    [ "pvData", "structiec104_1_1s_i_e_c104_data_attribute_data_adc03104137fe5b5422cef4a33d12093c.html#adc03104137fe5b5422cef4a33d12093c", null ],
    [ "sTimeStamp", "structiec104_1_1s_i_e_c104_data_attribute_data_a1d836cb19cb4c2ed01e7b2c562b06163.html#a1d836cb19cb4c2ed01e7b2c562b06163", null ],
    [ "tQuality", "structiec104_1_1s_i_e_c104_data_attribute_data_a78cac0ecd65106b288636c635923ab71.html#a78cac0ecd65106b288636c635923ab71", null ],
    [ "u16ElapsedTime", "structiec104_1_1s_i_e_c104_data_attribute_data_a2bda28c3eb01605423e0c890201e5e4c.html#a2bda28c3eb01605423e0c890201e5e4c", null ]
];