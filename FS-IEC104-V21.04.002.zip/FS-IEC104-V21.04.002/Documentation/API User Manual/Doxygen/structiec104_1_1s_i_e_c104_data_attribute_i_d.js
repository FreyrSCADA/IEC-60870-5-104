var structiec104_1_1s_i_e_c104_data_attribute_i_d =
[
    [ "ai8IPAddress", "structiec104_1_1s_i_e_c104_data_attribute_i_d_ac20adf52d56760cbce6b339b5d202d83.html#ac20adf52d56760cbce6b339b5d202d83", null ],
    [ "eTypeID", "structiec104_1_1s_i_e_c104_data_attribute_i_d_a179f212f4056549891b17af8f325826f.html#a179f212f4056549891b17af8f325826f", null ],
    [ "pvUserData", "structiec104_1_1s_i_e_c104_data_attribute_i_d_adc14a35c69e677a1ceed2a41bed2e8a0.html#adc14a35c69e677a1ceed2a41bed2e8a0", null ],
    [ "u16CommonAddress", "structiec104_1_1s_i_e_c104_data_attribute_i_d_a2ea111ed87af170d730eedf34b51e443.html#a2ea111ed87af170d730eedf34b51e443", null ],
    [ "u16PortNumber", "structiec104_1_1s_i_e_c104_data_attribute_i_d_af633601c92b41a263568ac59fdbf4a09.html#af633601c92b41a263568ac59fdbf4a09", null ],
    [ "u32IOA", "structiec104_1_1s_i_e_c104_data_attribute_i_d_a8529b963e559d8108a97ec0af44ac7f9.html#a8529b963e559d8108a97ec0af44ac7f9", null ]
];