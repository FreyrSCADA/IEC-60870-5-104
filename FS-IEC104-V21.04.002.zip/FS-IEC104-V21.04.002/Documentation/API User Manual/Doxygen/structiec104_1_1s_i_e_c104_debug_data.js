var structiec104_1_1s_i_e_c104_debug_data =
[
    [ "ai8IPAddress", "structiec104_1_1s_i_e_c104_debug_data_ac20adf52d56760cbce6b339b5d202d83.html#ac20adf52d56760cbce6b339b5d202d83", null ],
    [ "au8ErrorMessage", "structiec104_1_1s_i_e_c104_debug_data_a96225f536612acdc6383af24c2110bf6.html#a96225f536612acdc6383af24c2110bf6", null ],
    [ "au8RxData", "structiec104_1_1s_i_e_c104_debug_data_ac3106e4e2afb58edeaf04931bf5876eb.html#ac3106e4e2afb58edeaf04931bf5876eb", null ],
    [ "au8TxData", "structiec104_1_1s_i_e_c104_debug_data_a683046c96b45d7b473277623644789d6.html#a683046c96b45d7b473277623644789d6", null ],
    [ "au8WarningMessage", "structiec104_1_1s_i_e_c104_debug_data_a08083593fe17c343e131e7c4896dc85e.html#a08083593fe17c343e131e7c4896dc85e", null ],
    [ "iErrorCode", "structiec104_1_1s_i_e_c104_debug_data_af81e010ed37ba944dc948d4366d24dc0.html#af81e010ed37ba944dc948d4366d24dc0", null ],
    [ "sTimeStamp", "structiec104_1_1s_i_e_c104_debug_data_a1d836cb19cb4c2ed01e7b2c562b06163.html#a1d836cb19cb4c2ed01e7b2c562b06163", null ],
    [ "tErrorvalue", "structiec104_1_1s_i_e_c104_debug_data_a446b07810ebe5953f7ad2619d43062c0.html#a446b07810ebe5953f7ad2619d43062c0", null ],
    [ "u16PortNumber", "structiec104_1_1s_i_e_c104_debug_data_af633601c92b41a263568ac59fdbf4a09.html#af633601c92b41a263568ac59fdbf4a09", null ],
    [ "u16RxCount", "structiec104_1_1s_i_e_c104_debug_data_ae695f324bed76f81663b2925fb06e0bd.html#ae695f324bed76f81663b2925fb06e0bd", null ],
    [ "u16TxCount", "structiec104_1_1s_i_e_c104_debug_data_a87163a95c9e161292e9b65cfbbd895f1.html#a87163a95c9e161292e9b65cfbbd895f1", null ],
    [ "u32DebugOptions", "structiec104_1_1s_i_e_c104_debug_data_a4b04c2763d19774386f00e6187688627.html#a4b04c2763d19774386f00e6187688627", null ]
];