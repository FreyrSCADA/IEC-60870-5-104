
For building the testprograms , we can use codeblock IDE and make


for compiling make, 

make -f iec104servertest.mak