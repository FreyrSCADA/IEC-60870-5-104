

    #  Max Size of IPV4  Address 
MAX_IPV4_ADDRSIZE = 16

    #  Max Size of IPV6  Address 
MAX_IPV6_ADDRSIZE = 40

    #  Max Size of License Path 
MAX_LICENSE_PATH = 242

    #  Max Size of Error Message sent to callback  
MAX_ERROR_MESSAGE = 255

    #  Max Size of Warning Message sent to callback  
MAX_WARNING_MESSAGE = 255